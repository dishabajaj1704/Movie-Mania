import { MovieDetailsPage } from "./movieDetails/MovieDetailsPage";
import { MoviePage } from "./MoviePage";
import { PageNotFound } from "./PageNotFound";
import { SearchPage } from "./SearchPage";
