import { Header } from "./Header";
import { Footer } from "./Footer";
import { MovieCard } from "./MovieCard";
import { AppRoutes } from "./AppRouters";
import { ScrollToTop } from "./ScrollToTop";